package com.example.adeelahmed.contactaddtask

import android.graphics.Bitmap

data class UserContactDetail(var userName:String, var userContactNumber:String, var UserImage:Bitmap?) {
}